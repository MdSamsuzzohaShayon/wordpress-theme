<div class="float-right">
    sidebar.php
<!--    --><?php //the_title(); ?>
<!---->
<!--    <div class="content">-->
<!--        --><?php //the_content(); ?>
<!--    </div>-->
<!---->
<!--    <div class="widget-section">-->
<!--        --><?php //the_widget( 'TSW_Popular_Posts_Widgets' ); ?>
<!--    </div>-->
<!--    --><?php //dynamic_sidebar('sidebar-1'); ?>
</div>