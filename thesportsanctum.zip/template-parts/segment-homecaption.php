

<div class="container caption-main d-flex justify-content-start align-items-center">
    <div class="col-md-6 col-sm-12 text-white">
        <h2 class="text-uppercase heading-caption text-shadow"> <?php echo get_theme_mod('thesportsanctum_caption_title_setting'); ?></h2>
        <p ><?php echo get_theme_mod('thesportsanctum_caption_description_setting'); ?></p>
    </div>
</div>
